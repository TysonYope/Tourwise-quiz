
import { useState } from 'react';

const questions = [
  { question: "What does the term 'hospitality' primarily refer to?", options: ["Travel Planning", "Hosting and Welcoming Guests", "Booking Flights", "Guided Tours"], answer: 1 },
  { question: "Which organization promotes global tourism?", options: ["WHO", "UNESCO", "WTO (World Tourism Organization)", "UNDP"], answer: 2 },
  { question: "What is ecotourism?", options: ["Luxury travel", "Nature-based responsible travel", "Business travel", "Adventure sports only"], answer: 1 },
  { question: "Which country is known for the Great Barrier Reef?", options: ["New Zealand", "Australia", "Fiji", "Indonesia"], answer: 1 },
  { question: "What kind of tourism focuses on historical landmarks and heritage?", options: ["Cultural Tourism", "Medical Tourism", "Rural Tourism", "Space Tourism"], answer: 0 },
  { question: "Which city is famous for the Eiffel Tower and attracts millions of tourists?", options: ["London", "Paris", "Rome", "Madrid"], answer: 1 },
  { question: "In which country would you find Machu Picchu?", options: ["Brazil", "Peru", "Chile", "Mexico"], answer: 1 },
  { question: "Which continent is home to the Sahara Desert and the Pyramids of Giza?", options: ["Asia", "Europe", "Africa", "Australia"], answer: 2 },
  { question: "What is the main purpose of medical tourism?", options: ["Relaxation", "Adventure", "Affordable Healthcare Abroad", "Cultural Immersion"], answer: 2 },
  { question: "Which country is known for its traditional tea ceremonies and cherry blossom festivals?", options: ["South Korea", "Japan", "China", "Vietnam"], answer: 1 }
];

export default function App() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index) => {
    if (index === questions[current].answer) {
      setScore(score + 1);
    }
    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      setShowResult(true);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '1rem' }}>
      <h1 style={{ fontSize: '2rem', textAlign: 'center' }}>TourWise Quiz</h1>
      {!showResult ? (
        <div style={{ marginBottom: '1rem' }}>
          <p style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{questions[current].question}</p>
          {questions[current].options.map((option, index) => (
            <button
              key={index}
              style={{ display: 'block', width: '100%', margin: '0.5rem 0', padding: '0.75rem', background: '#f0f0f0', border: '1px solid #ccc', borderRadius: '5px' }}
              onClick={() => handleAnswer(index)}
            >
              {option}
            </button>
          ))}
        </div>
      ) : (
        <div>
          <h2 style={{ fontSize: '1.5rem' }}>Your Score: {score} / {questions.length}</h2>
          <button onClick={() => { setCurrent(0); setScore(0); setShowResult(false); }} style={{ marginTop: '1rem', padding: '0.75rem 1rem', background: '#007bff', color: '#fff', border: 'none', borderRadius: '5px' }}>
            Try Again
          </button>
        </div>
      )}
    </div>
  );
}
